# 🪄 Arcane Arsenal

**Minecraft Fabric Mod — Version 1.21.1**

Ajoute 4 baguettes élémentaires avec des effets de zone puissants, craftées à partir d'un **Cristal de Mana**.

---

## 📦 Installation

### Prérequis
- **Minecraft Java Edition** `1.21.1`
- **Fabric Loader** `≥ 0.15.0` ([download](https://fabricmc.net/use/installer/))
- **Fabric API** `0.100.8+1.21.1` ([Modrinth](https://modrinth.com/mod/fabric-api))

### Compilation
```bash
# Cloner / extraire le projet
./gradlew build
# Le .jar se trouve dans build/libs/arcane-arsenal-1.0.0.jar
```

---

## 🔮 Cristal de Mana (ingrédient)

Requis pour toutes les baguettes.

```
[ Lapis ][ Améthyste ][ Lapis     ]
[ Améth ][ Diamant   ][ Améthyste ]
[ Lapis ][ Améthyste ][ Lapis     ]
```
→ **2× Cristal de Mana**

---

## 🪄 Baguettes

Toutes les baguettes suivent le même pattern de craft :

```
[  Ingrédient   ]
[ Cristal Mana  ]
[    Bâton      ]
```

### 🔥 Baguette de Feu
| Propriété     | Valeur         |
|---------------|----------------|
| Ingrédient    | Tige de Blaze  |
| Rayon d'effet | 6 blocs        |
| Durée feu     | 5 secondes     |
| Cooldown      | 3 secondes     |

**Effet :** Enflamme toutes les entités vivantes dans le rayon. Effets visuels de flammes et fumée.

---

### 🧊 Baguette de Glace
| Propriété     | Valeur              |
|---------------|---------------------|
| Ingrédient    | Glace bleue         |
| Rayon d'effet | 8 blocs             |
| Effets        | Lenteur IV + Faiblesse II (5s) + Gel 7s |
| Cooldown      | 4 secondes          |

**Effet :** Gèle et ralentit toutes les entités dans le rayon. Utilise le système de gel natif de Minecraft (comme les Pics Glacés).

---

### 💨 Baguette de Vent
| Propriété       | Valeur                |
|-----------------|-----------------------|
| Ingrédient      | Plume                 |
| Rayon knockback | 7 blocs               |
| Propulsion      | ~1.2 blocs vers le haut |
| Effets          | Chute lente (4s) + knockback directionnel |
| Cooldown        | 2.5 secondes          |

**Effet :** Te propulse dans les airs avec chute lente automatique. Repousse les entités proches proportionnellement à leur distance.

---

### 🪨 Baguette de Terre
| Propriété        | Valeur                      |
|------------------|-----------------------------|
| Ingrédient       | Cobblestone                 |
| Portée de visée  | 10 blocs                    |
| Pilier central   | 4 blocs de haut             |
| Piliers latéraux | 2 blocs de haut (N/S/E/W)   |
| Durée piliers    | 10 secondes puis disparition |
| Cooldown         | 5 secondes                  |

**Effet :** Invoque une formation de 5 piliers de pierre sur le bloc visé. Les piliers disparaissent après 10 secondes sans détruire les constructions existantes.

---

## 🛠️ Structure du projet

```
src/main/java/net/arcanearsenal/
├── ArcaneArsenal.java          ← Point d'entrée du mod
└── item/
    ├── ModItems.java           ← Enregistrement des items
    ├── FireWandItem.java       ← Logique baguette de feu
    ├── IceWandItem.java        ← Logique baguette de glace
    ├── WindWandItem.java       ← Logique baguette de vent
    └── EarthWandItem.java      ← Logique baguette de terre
```

---

## 📝 Notes techniques

- Tous les effets sont exécutés **côté serveur** (`!world.isClient()`) pour la compatibilité multijoueur.
- Les particules sont envoyées via `ServerWorld.spawnParticles()` pour être visibles de tous les joueurs proches.
- La baguette de Terre utilise un thread de nettoyage pour supprimer les piliers après leur durée de vie.
- Toutes les baguettes ont l'**effet brillant** (glint) activé en permanence.

---

## 📄 Licence

MIT — Libre d'utilisation, modification et distribution.
