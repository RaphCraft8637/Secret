package net.arcanearsenal.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/**
 * ════════════════════════════════════════════════
 *  🔥  BAGUETTE DE FEU
 * ════════════════════════════════════════════════
 *
 * Clic droit → embrase toutes les entités vivantes
 * dans un rayon de {@value #RADIUS} blocs pendant
 * {@value #FIRE_DURATION_SECONDS} secondes.
 *
 * Cooldown : {@value #COOLDOWN_TICKS} ticks (3 s)
 * ════════════════════════════════════════════════
 */
public class FireWandItem extends Item {

    private static final float RADIUS               = 6.0f;
    private static final int   FIRE_DURATION_SECONDS = 5;
    private static final int   COOLDOWN_TICKS        = 60;   // 3 secondes

    public FireWandItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (!world.isClient()) {
            ServerWorld serverWorld = (ServerWorld) world;

            // Récupère toutes les entités dans le rayon
            List<Entity> nearbyEntities = world.getOtherEntities(
                    user,
                    user.getBoundingBox().expand(RADIUS)
            );

            int ignited = 0;
            for (Entity entity : nearbyEntities) {
                if (entity instanceof LivingEntity living && !entity.equals(user)) {
                    living.setOnFireFor(FIRE_DURATION_SECONDS);
                    ignited++;

                    // Particules de flamme sur chaque cible
                    serverWorld.spawnParticles(
                            ParticleTypes.FLAME,
                            entity.getX(), entity.getY() + entity.getHeight() / 2.0, entity.getZ(),
                            20, 0.4, 0.5, 0.4, 0.05
                    );
                }
            }

            // Particules autour du joueur
            serverWorld.spawnParticles(
                    ParticleTypes.LARGE_SMOKE,
                    user.getX(), user.getY() + 1.0, user.getZ(),
                    15, RADIUS * 0.5, 0.5, RADIUS * 0.5, 0.02
            );

            // Son de Blaze
            world.playSound(
                    null, user.getBlockPos(),
                    SoundEvents.ENTITY_BLAZE_SHOOT,
                    SoundCategory.PLAYERS,
                    1.0f, 0.8f
            );

            // Feedback joueur
            if (ignited > 0) {
                user.sendMessage(
                        Text.literal("🔥 " + ignited + " entité(s) en feu !"),
                        true
                );
            } else {
                user.sendMessage(
                        Text.literal("🔥 Aucune cible dans le rayon."),
                        true
                );
            }
        }

        // Applique le cooldown
        user.getItemCooldownManager().set(this, COOLDOWN_TICKS);
        return TypedActionResult.success(stack);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true; // Effet brillant en permanence
    }
}
