package net.arcanearsenal.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/**
 * ════════════════════════════════════════════════
 *  🧊  BAGUETTE DE GLACE
 * ════════════════════════════════════════════════
 *
 * Clic droit → applique aux entités vivantes dans
 * un rayon de {@value #RADIUS} blocs :
 *   • Lenteur IV  (5 secondes)
 *   • Faiblesse II (5 secondes)
 *   • Gel progressif (frozenTicks)
 *
 * Cooldown : {@value #COOLDOWN_TICKS} ticks (4 s)
 * ════════════════════════════════════════════════
 */
public class IceWandItem extends Item {

    private static final float RADIUS          = 8.0f;
    private static final int   EFFECT_DURATION = 100;   // 5 secondes
    private static final int   FREEZE_TICKS    = 140;   // ~7 secondes de gel
    private static final int   COOLDOWN_TICKS  = 80;    // 4 secondes

    public IceWandItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (!world.isClient()) {
            ServerWorld serverWorld = (ServerWorld) world;

            List<Entity> nearbyEntities = world.getOtherEntities(
                    user,
                    user.getBoundingBox().expand(RADIUS)
            );

            int frozen = 0;
            for (Entity entity : nearbyEntities) {
                if (entity instanceof LivingEntity living && !entity.equals(user)) {

                    // Effets de potion
                    living.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.SLOWNESS, EFFECT_DURATION, 3, false, true
                    ));
                    living.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.WEAKNESS, EFFECT_DURATION, 1, false, true
                    ));

                    // Gel natif de Minecraft (comme le biome des Pics Glacés)
                    living.setFrozenTicks(FREEZE_TICKS);

                    // Particules de neige
                    serverWorld.spawnParticles(
                            ParticleTypes.SNOWFLAKE,
                            entity.getX(), entity.getY() + entity.getHeight() / 2.0, entity.getZ(),
                            25, 0.5, 0.7, 0.5, 0.05
                    );

                    frozen++;
                }
            }

            // Nuage de givre autour du lanceur
            serverWorld.spawnParticles(
                    ParticleTypes.SNOWFLAKE,
                    user.getX(), user.getY() + 1.0, user.getZ(),
                    60, RADIUS * 0.6, 0.3, RADIUS * 0.6, 0.02
            );
            serverWorld.spawnParticles(
                    ParticleTypes.ITEM_SNOWBALL,
                    user.getX(), user.getY() + 1.0, user.getZ(),
                    30, RADIUS * 0.4, 0.5, RADIUS * 0.4, 0.1
            );

            // Son de glace
            world.playSound(
                    null, user.getBlockPos(),
                    SoundEvents.BLOCK_GLASS_BREAK,
                    SoundCategory.PLAYERS,
                    1.0f, 0.5f
            );
            world.playSound(
                    null, user.getBlockPos(),
                    SoundEvents.ENTITY_PLAYER_HURT_FREEZE,
                    SoundCategory.PLAYERS,
                    1.0f, 1.0f
            );

            // Feedback
            if (frozen > 0) {
                user.sendMessage(
                        Text.literal("🧊 " + frozen + " entité(s) gelée(s) !"),
                        true
                );
            } else {
                user.sendMessage(
                        Text.literal("🧊 Aucune cible dans le rayon."),
                        true
                );
            }
        }

        user.getItemCooldownManager().set(this, COOLDOWN_TICKS);
        return TypedActionResult.success(stack);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
}
