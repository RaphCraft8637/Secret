package net.arcanearsenal.item;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * ════════════════════════════════════════════════
 *  🪨  BAGUETTE DE TERRE
 * ════════════════════════════════════════════════
 *
 * Clic droit (en visant un bloc) → invoque une
 * formation de piliers de pierre sur le bloc ciblé
 * et ses 4 voisins cardinaux.
 *
 *  • Pilier central  : {@value #CENTER_HEIGHT} blocs
 *  • Piliers latéraux: {@value #SIDE_HEIGHT} blocs
 *  • Les piliers se détruisent automatiquement
 *    après {@value #LIFETIME_TICKS} ticks (~10 s)
 *
 * Cooldown : {@value #COOLDOWN_TICKS} ticks (5 s)
 * ════════════════════════════════════════════════
 */
public class EarthWandItem extends Item {

    private static final int   CENTER_HEIGHT  = 4;
    private static final int   SIDE_HEIGHT    = 2;
    private static final int   COOLDOWN_TICKS = 100;     // 5 secondes
    private static final int   LIFETIME_TICKS = 200;     // 10 secondes
    private static final float MAX_REACH      = 10.0f;

    // Quels blocs on peut viser (pas l'air, pas le bédrock)
    private static final Block PILLAR_BLOCK   = Blocks.STONE;

    public EarthWandItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        // Lancer de rayon pour trouver le bloc visé
        HitResult hitResult = user.raycast(MAX_REACH, 0.0f, false);

        if (hitResult.getType() != HitResult.Type.BLOCK) {
            if (!world.isClient()) {
                user.sendMessage(Text.literal("🪨 Vise un bloc pour invoquer les piliers !"), true);
            }
            return TypedActionResult.fail(stack);
        }

        BlockHitResult blockHit = (BlockHitResult) hitResult;
        BlockPos targetPos = blockHit.getBlockPos();

        // Ne pas invoquer à l'intérieur du bédrock ou si le bloc au-dessus est occupé
        if (world.getBlockState(targetPos).isOf(Blocks.BEDROCK)) {
            if (!world.isClient()) {
                user.sendMessage(Text.literal("🪨 Ce bloc est trop résistant !"), true);
            }
            return TypedActionResult.fail(stack);
        }

        if (!world.isClient()) {
            ServerWorld serverWorld = (ServerWorld) world;
            BlockState stoneState = PILLAR_BLOCK.getDefaultState();

            // ── Pilier central ──────────────────────────────────────────
            spawnPillar(serverWorld, targetPos.up(), CENTER_HEIGHT, stoneState);

            // ── Piliers latéraux (N/S/E/W) ─────────────────────────────
            spawnPillar(serverWorld, targetPos.north().up(), SIDE_HEIGHT, stoneState);
            spawnPillar(serverWorld, targetPos.south().up(), SIDE_HEIGHT, stoneState);
            spawnPillar(serverWorld, targetPos.east().up(),  SIDE_HEIGHT, stoneState);
            spawnPillar(serverWorld, targetPos.west().up(),  SIDE_HEIGHT, stoneState);

            // ── Particules de terre ─────────────────────────────────────
            BlockStateParticleEffect dirtParticle = new BlockStateParticleEffect(
                    ParticleTypes.BLOCK,
                    Blocks.DIRT.getDefaultState()
            );
            BlockStateParticleEffect stoneParticle = new BlockStateParticleEffect(
                    ParticleTypes.BLOCK,
                    stoneState
            );

            for (int i = 0; i < CENTER_HEIGHT; i++) {
                serverWorld.spawnParticles(
                        dirtParticle,
                        targetPos.getX() + 0.5,
                        targetPos.getY() + 1.0 + i,
                        targetPos.getZ() + 0.5,
                        12, 0.4, 0.1, 0.4, 0.08
                );
                serverWorld.spawnParticles(
                        stoneParticle,
                        targetPos.getX() + 0.5,
                        targetPos.getY() + 1.0 + i,
                        targetPos.getZ() + 0.5,
                        8, 0.5, 0.1, 0.5, 0.06
                );
            }

            // ── Sons ────────────────────────────────────────────────────
            BlockSoundGroup sounds = stoneState.getSoundGroup();
            world.playSound(
                    null, targetPos,
                    sounds.getPlaceSound(),
                    SoundCategory.BLOCKS,
                    1.5f, 0.7f
            );
            world.playSound(
                    null, targetPos,
                    SoundEvents.ENTITY_RAVAGER_ROAR,
                    SoundCategory.PLAYERS,
                    0.6f, 0.5f
            );

            // ── Planifier la destruction automatique ────────────────────
            // On utilise un thread de schedule basique
            final BlockPos finalTarget = targetPos;
            new Thread(() -> {
                try {
                    Thread.sleep(LIFETIME_TICKS * 50L); // ticks → ms
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                }
                if (!serverWorld.isClient()) {
                    serverWorld.getServer().execute(() ->
                            removePillars(serverWorld, finalTarget, stoneState)
                    );
                }
            }, "EarthWand-Cleanup").start();

            // ── Feedback ────────────────────────────────────────────────
            user.sendMessage(
                    Text.literal("🪨 Piliers invoqués ! Ils s'effondreront dans 10 secondes."),
                    true
            );
        }

        user.getItemCooldownManager().set(this, COOLDOWN_TICKS);
        return TypedActionResult.success(stack);
    }

    /**
     * Place une colonne de {@code height} blocs à partir de {@code base}.
     * Ne place des blocs que dans de l'air (ne détruit pas les structures existantes).
     */
    private void spawnPillar(ServerWorld world, BlockPos base, int height, BlockState state) {
        for (int i = 0; i < height; i++) {
            BlockPos pos = base.up(i);
            if (world.getBlockState(pos).isAir()) {
                world.setBlockState(pos, state);
            }
        }
    }

    /**
     * Supprime les blocs de pierre posés par la baguette (uniquement si c'est
     * toujours le bloc d'origine — ne détruit pas les constructions du joueur).
     */
    private void removePillars(ServerWorld world, BlockPos target, BlockState expected) {
        removeColumn(world, target.up(),         CENTER_HEIGHT, expected);
        removeColumn(world, target.north().up(), SIDE_HEIGHT,   expected);
        removeColumn(world, target.south().up(), SIDE_HEIGHT,   expected);
        removeColumn(world, target.east().up(),  SIDE_HEIGHT,   expected);
        removeColumn(world, target.west().up(),  SIDE_HEIGHT,   expected);

        // Petite explosion de particules lors de l'effondrement
        world.spawnParticles(
                new BlockStateParticleEffect(ParticleTypes.BLOCK, expected),
                target.getX() + 0.5, target.getY() + CENTER_HEIGHT, target.getZ() + 0.5,
                40, 1.0, 0.5, 1.0, 0.2
        );
    }

    private void removeColumn(ServerWorld world, BlockPos base, int height, BlockState expected) {
        for (int i = 0; i < height; i++) {
            BlockPos pos = base.up(i);
            if (world.getBlockState(pos).equals(expected)) {
                world.setBlockState(pos, Blocks.AIR.getDefaultState());
            }
        }
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
}
