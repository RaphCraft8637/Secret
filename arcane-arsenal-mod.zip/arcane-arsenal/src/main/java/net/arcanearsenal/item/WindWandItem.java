package net.arcanearsenal.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;

/**
 * ════════════════════════════════════════════════
 *  💨  BAGUETTE DE VENT
 * ════════════════════════════════════════════════
 *
 * Clic droit → double effet :
 *   1. Propulse le joueur vers le haut (saut élevé)
 *      + Chute lente pendant 3 secondes
 *   2. Repousse toutes les entités proches
 *      ({@value #KNOCKBACK_RADIUS} blocs) en les
 *      éjectant avec force
 *
 * Cooldown : {@value #COOLDOWN_TICKS} ticks (2.5 s)
 * ════════════════════════════════════════════════
 */
public class WindWandItem extends Item {

    private static final float  KNOCKBACK_RADIUS   = 7.0f;
    private static final double PLAYER_LIFT        = 1.2;    // Force vers le haut
    private static final double KNOCKBACK_STRENGTH = 2.0;    // Force de répulsion
    private static final int    SLOW_FALL_DURATION = 80;     // 4 secondes de chute lente
    private static final int    COOLDOWN_TICKS     = 50;     // 2.5 secondes

    public WindWandItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (!world.isClient()) {
            ServerWorld serverWorld = (ServerWorld) world;

            // ── 1. Propulser le joueur ──────────────────────────────────
            Vec3d currentVelocity = user.getVelocity();
            user.setVelocity(currentVelocity.x, PLAYER_LIFT, currentVelocity.z);
            user.velocityModified = true;

            // Chute lente pour un atterrissage gracieux
            user.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.SLOW_FALLING, SLOW_FALL_DURATION, 0, false, false
            ));

            // ── 2. Repousser les entités proches ────────────────────────
            List<Entity> nearbyEntities = world.getOtherEntities(
                    user,
                    user.getBoundingBox().expand(KNOCKBACK_RADIUS)
            );

            int pushed = 0;
            Vec3d userPos = user.getPos();

            for (Entity entity : nearbyEntities) {
                if (entity instanceof LivingEntity && !entity.equals(user)) {
                    // Vecteur de répulsion : de l'utilisateur vers l'entité
                    Vec3d direction = entity.getPos().subtract(userPos).normalize();

                    // Distance (pour atténuer la force selon la distance)
                    double distance = entity.getPos().distanceTo(userPos);
                    double force = KNOCKBACK_STRENGTH * (1.0 - (distance / KNOCKBACK_RADIUS) * 0.5);

                    entity.setVelocity(
                            direction.x * force,
                            0.6 + (force * 0.3),    // légère composante verticale
                            direction.z * force
                    );
                    entity.velocityModified = true;

                    // Particules d'explosion d'air sur la cible
                    serverWorld.spawnParticles(
                            ParticleTypes.POOF,
                            entity.getX(), entity.getY() + entity.getHeight() / 2.0, entity.getZ(),
                            10, 0.3, 0.3, 0.3, 0.1
                    );

                    pushed++;
                }
            }

            // ── Particules de vent ──────────────────────────────────────
            // Spirale de particules autour du joueur
            for (int i = 0; i < 3; i++) {
                double angle = (i / 3.0) * 2 * Math.PI;
                serverWorld.spawnParticles(
                        ParticleTypes.CLOUD,
                        user.getX() + Math.cos(angle) * 2.0,
                        user.getY() + 0.5,
                        user.getZ() + Math.sin(angle) * 2.0,
                        8, 0.3, 0.2, 0.3, 0.05
                );
            }
            serverWorld.spawnParticles(
                    ParticleTypes.POOF,
                    user.getX(), user.getY(), user.getZ(),
                    30, KNOCKBACK_RADIUS * 0.5, 0.5, KNOCKBACK_RADIUS * 0.5, 0.15
            );

            // ── Sons ────────────────────────────────────────────────────
            world.playSound(
                    null, user.getBlockPos(),
                    SoundEvents.ENTITY_BREEZE_SHOOT,
                    SoundCategory.PLAYERS,
                    1.2f, 1.0f
            );
            world.playSound(
                    null, user.getBlockPos(),
                    SoundEvents.ENTITY_BREEZE_JUMP,
                    SoundCategory.PLAYERS,
                    1.0f, 0.9f
            );

            // ── Feedback ────────────────────────────────────────────────
            String msg = pushed > 0
                    ? "💨 Propulsé ! " + pushed + " entité(s) repoussée(s)."
                    : "💨 Propulsé dans les airs !";
            user.sendMessage(Text.literal(msg), true);
        }

        user.getItemCooldownManager().set(this, COOLDOWN_TICKS);
        return TypedActionResult.success(stack);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
}
