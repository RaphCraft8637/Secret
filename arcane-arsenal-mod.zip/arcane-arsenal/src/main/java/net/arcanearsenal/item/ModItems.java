package net.arcanearsenal.item;

import net.arcanearsenal.ArcaneArsenal;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/**
 * Enregistre tous les items du mod dans les registres Minecraft.
 */
public class ModItems {

    // ── Cristal de Mana (ingrédient de craft pour toutes les baguettes) ────
    public static final Item MANA_CRYSTAL = register(
            "mana_crystal",
            new Item(new Item.Settings().maxCount(64))
    );

    // ── Baguette de Feu ────────────────────────────────────────────────────
    // Brûle toutes les entités dans un rayon de 6 blocs pendant 5 secondes
    public static final Item FIRE_WAND = register(
            "fire_wand",
            new FireWandItem(new Item.Settings().maxCount(1))
    );

    // ── Baguette de Glace ──────────────────────────────────────────────────
    // Applique Lenteur IV + effet de gel aux entités dans un rayon de 8 blocs
    public static final Item ICE_WAND = register(
            "ice_wand",
            new IceWandItem(new Item.Settings().maxCount(1))
    );

    // ── Baguette de Vent ───────────────────────────────────────────────────
    // Propulse le joueur vers le haut et repousse les ennemis proches
    public static final Item WIND_WAND = register(
            "wind_wand",
            new WindWandItem(new Item.Settings().maxCount(1))
    );

    // ── Baguette de Terre ──────────────────────────────────────────────────
    // Invoque des piliers de pierre à l'endroit regardé
    public static final Item EARTH_WAND = register(
            "earth_wand",
            new EarthWandItem(new Item.Settings().maxCount(1))
    );

    // ──────────────────────────────────────────────────────────────────────
    private static Item register(String name, Item item) {
        return Registry.register(
                Registries.ITEM,
                Identifier.of(ArcaneArsenal.MOD_ID, name),
                item
        );
    }

    /**
     * Appeler depuis le ModInitializer pour déclencher le chargement de la classe
     * et ainsi enregistrer tous les items.
     */
    public static void registerItems() {
        // Ajouter les items dans le groupe "Outils" du menu créatif
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(MANA_CRYSTAL);
            entries.add(FIRE_WAND);
            entries.add(ICE_WAND);
            entries.add(WIND_WAND);
            entries.add(EARTH_WAND);
        });

        ArcaneArsenal.LOGGER.info("[Arcane Arsenal] {} items enregistrés.", 5);
    }
}
