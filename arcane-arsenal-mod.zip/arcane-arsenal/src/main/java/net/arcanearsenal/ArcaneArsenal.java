package net.arcanearsenal;

import net.arcanearsenal.item.ModItems;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Arcane Arsenal — Mod principal
 *
 * Ajoute 4 baguettes élémentaires :
 *  - Baguette de Feu    : brûle les entités proches en zone
 *  - Baguette de Glace  : ralentit et gèle les entités proches
 *  - Baguette de Vent   : propulse le joueur et repousse les ennemis
 *  - Baguette de Terre  : invoque des piliers de pierre
 *
 * Nécessite un Cristal de Mana comme ingrédient pour toutes les baguettes.
 */
public class ArcaneArsenal implements ModInitializer {

    public static final String MOD_ID = "arcanearsenal";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.registerItems();
        LOGGER.info("[Arcane Arsenal] Baguettes élémentaires prêtes !");
    }
}
